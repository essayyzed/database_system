<?php

namespace ColibriWP\Theme\BuilderComponents;


class Sidebar extends BuilderComponentBase {

    /**
     * @return string
     */
    protected function getName() {
        return 'sidebar';
    }
}
