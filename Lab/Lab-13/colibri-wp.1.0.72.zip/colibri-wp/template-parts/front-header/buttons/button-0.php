<span class="h-button__outer style-25-outer style-local-7-h31-outer d-inline-flex h-element">
  <a h-use-smooth-scroll="true" href="<?php echo esc_attr(\ColibriWP\Theme\View::getData( 'url' )); ?>" data-colibri-id="7-h31" class="d-flex w-100 align-items-center h-button justify-content-lg-center justify-content-md-center justify-content-center style-25 style-local-7-h31 position-relative">
    <span>
      <?php echo esc_html(\ColibriWP\Theme\View::getData( 'label' )); ?>
    </span>
  </a>
</span>
